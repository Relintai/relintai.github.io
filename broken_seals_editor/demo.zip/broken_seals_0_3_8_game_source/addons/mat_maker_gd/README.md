# mat_maker_gd

My goal with this project is to take Material Maker's ( https://github.com/RodZill4/material-maker ) code,
and make it an in-godot texture/image generator.

If it turns out well I'll probably turn it into a c++ engine module eventually.

Multi threading uses my threadpool engine module for now.

## Status:

Missing ~ 60 nodes from ~ 195.

## TODOS

- [ ] Go through the current MaterialMaker and add the code from all the new nodes.
- [ ] Go through the current MaterialMaker and update any old code.
- [ ] Add note to all files that has code from MaterialMaker.
- [ ] Proper readme.md.
- [ ] Per node seed like in the original.
- [ ] Port all the nodes. Missing ~ 60 from ~ 195
- [ ] Somehow get ctrl-s to always just save the edited material, instead of having to double click it (for the inspector to update), and then clicking the save icon and selecting save.
