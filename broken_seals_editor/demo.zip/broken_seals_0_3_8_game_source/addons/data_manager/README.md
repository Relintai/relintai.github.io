# ESS Data

This is an addon for https://github.com/Relintai/entity_spell_system, to help with editing, and managing all game related the data in the project.

Looks like this:

![ess_data screenshot](screenshots/ess_data.png)
