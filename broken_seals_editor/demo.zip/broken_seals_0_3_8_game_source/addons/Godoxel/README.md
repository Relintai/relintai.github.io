# Godoxel (image Editor) v0.1
###### (Godot-Pixel Image Editor)


Godoxel is an image editor for Godot, that can be used inside the editor.



## Features

* Has basic pixel editor functionality
* Save/Load
* Multiple layers (can be locked/hidden)
* Tools: Pencil, lighten/darken, rectangle/line, fill, ...

---
###### For feature proposals or occuring problems, please write an issue or message me on Discord cobrapitz#2872
